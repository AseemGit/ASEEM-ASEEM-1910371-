-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 12, 2022 at 01:44 PM
-- Server version: 5.6.48-log
-- PHP Version: 7.4.5RC1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database1910371`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `firstname` char(20) NOT NULL,
  `lastname` char(20) NOT NULL,
  `address` char(25) NOT NULL,
  `city` char(25) NOT NULL,
  `postalcode` char(7) NOT NULL,
  `username` char(15) NOT NULL,
  `password` char(255) NOT NULL,
  `customer_picture` char(255) NOT NULL,
  `creation_date_time` datetime NOT NULL,
  `modification_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `firstname`, `lastname`, `address`, `city`, `postalcode`, `username`, `password`, `customer_picture`, `creation_date_time`, `modification_date_time`) VALUES
(1, 'Michael', 'Thomas', '356 OLD STEESE HWY', 'FAIRBANKS', '455646', 'michael', '0acf4539a14b3aa27deeb4cbdf6e989f', 'customerimage/michael.jpg', '2022-12-03 02:13:13', '2022-12-03 05:15:06'),
(2, 'Smith', 'Thomas', '9400 GLACIER HWY', 'FAIRBANKS', '456465', 'smith', 'a66e44736e753d4533746ced572ca821', 'customerimage/smith.jpg', '2022-12-03 02:13:13', '2022-12-03 05:15:06'),
(3, 'John', 'Smith', 'STE. 10 BLDG 1', 'ANCHORAGE', '456456', 'john', '527bd5b5d689e2c32ae974c6229ff785', 'customerimage/john.png', '2022-12-03 02:13:13', '2022-12-03 05:15:06'),
(4, 'Williams', 'Lopez', 'SUITE 170', 'ANCHORAGE', '456746', 'williams', '44e7cdc8f1386a1820b02f504f38317d', 'customerimage/williams.jpg', '2022-12-03 02:13:13', '2022-12-03 05:15:06'),
(5, 'Brown1', 'Moore', '2131 S MCKENZIE ST.', 'FOLEY', '4556646', 'brown', '6f7e9ca1d5ce4c84b69d7793f4de8e23', 'customerimage/brown.png', '2022-12-03 02:13:13', '2022-12-03 02:13:13'),
(7, 'swaleha', 'parveen', 'test', 'jbp', '48546', 'swaleha', '202cb962ac59075b964b07152d234b70', '1670330926_team-2.jpg', '2022-12-06 12:36:38', '2022-12-06 12:48:46'),
(8, 'Shraddha', 'Pathak', 'test', 'Jabalpur', '482003', 'test123', '202cb962ac59075b964b07152d234b70', '1670331154_barelal.jpeg', '2022-12-06 12:52:34', '2022-12-06 12:52:34'),
(12, 'shraddha', 'pathak', 'test', 'jabalpur', '4820003', 'shradha', '4297f44b13955235245b2497399d7a93', '1670505808_Sri-Padmanabhaswamy-Temple-Mahavishnu-Idol-32-KG.jpg', '2022-12-08 13:23:28', '2022-12-08 13:23:28'),
(13, 'shraddha', 'pathak', 'test', 'jabalpur', '4820003', 'shraddha', '4297f44b13955235245b2497399d7a93', '1670505818_Sri-Padmanabhaswamy-Temple-Mahavishnu-Idol-32-KG.jpg', '2022-12-08 13:23:38', '2022-12-08 13:23:38'),
(14, 'vipin', 'pathak', 'test', 'jabalpur', '123123', 'vipin', '202cb962ac59075b964b07152d234b70', '1670505935_photo_2022-11-10_19-24-09.jpg', '2022-12-08 13:25:35', '2022-12-08 13:25:35'),
(15, 'test', 'test', 'test', 'as', 'asdfasf', 'test', '098f6bcd4621d373cade4e832627b4f6', '1670505989_photo_2022-11-10_19-24-09.jpg', '2022-12-08 13:26:29', '2022-12-08 13:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(10,2) NOT NULL,
  `subtotal` float(10,2) NOT NULL,
  `tax_amount` float(10,2) NOT NULL,
  `grand_total` float(10,2) NOT NULL,
  `comments` char(200) DEFAULT NULL,
  `order_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customerId`, `productId`, `quantity`, `price`, `subtotal`, `tax_amount`, `grand_total`, `comments`, `order_date_time`) VALUES
(1, 1, 2, 2, 17.00, 34.00, 5.47, 39.40, NULL, '2022-12-03 16:19:57'),
(2, 2, 4, 5, 55.00, 275.00, 44.27, 319.27, 'It is a long established', '2022-12-03 16:21:45'),
(3, 4, 3, 4, 15.00, 60.00, 9.66, 69.66, NULL, '2022-12-04 16:22:50'),
(4, 4, 4, 4, 55.00, 220.00, 35.42, 255.42, NULL, '2022-12-03 16:23:46'),
(5, 1, 5, 2, 5.00, 10.00, 1.61, 11.61, 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', '2022-12-03 16:25:16'),
(6, 7, 2, 3, 17.00, 51.00, 6.99, 57.99, 'Contrary to popular belief, Lorem Ipsum is not simply random text', '2022-12-06 12:50:04'),
(7, 8, 2, 2, 17.00, 34.00, 4.66, 38.66, 'test', '2022-12-06 12:53:38');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_code` char(12) NOT NULL,
  `description` char(100) NOT NULL,
  `retail_price` float(10,2) NOT NULL,
  `cost_price` float(10,2) DEFAULT NULL,
  `creation_date_time` datetime NOT NULL,
  `modification_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_code`, `description`, `retail_price`, `cost_price`, `creation_date_time`, `modification_date_time`) VALUES
(1, '438-prd-test', 'It is a long established fact that a reader will be distracted by the readable content of a page whe', 15.00, 20.00, '2022-12-03 15:57:00', '2022-12-03 15:57:00'),
(2, '565-prd-test', 'It is a long established fact that a reader will be distracted by the readable content of a page whe', 17.00, NULL, '2022-12-03 15:57:00', '2022-12-03 15:57:00'),
(3, '74897-prd-te', 'It is a long established fact that a reader will be distracted by the readable content of a page whe', 15.00, 25.00, '2022-12-03 15:57:00', '2022-12-03 15:57:00'),
(4, '4568-prd-tes', 'It is a long established fact that a reader will be distracted by the readable content of a page whe', 55.00, NULL, '2022-12-03 15:57:00', '2022-12-03 15:57:00'),
(5, '4448-prd-tes', 'It is a long established fact that a reader will be distracted by the readable content of a page whe', 5.00, 40.00, '2022-12-03 15:57:00', '2022-12-03 15:57:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`,`product_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
